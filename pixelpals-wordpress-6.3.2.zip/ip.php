<?php
$output = shell_exec('./ip.sh');
echo "<pre>$output</pre>";
?>
